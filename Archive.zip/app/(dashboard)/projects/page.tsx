import Link from "next/link";
import { FolderKanban, Plus } from "lucide-react";

import { prisma } from "@/lib/prisma";

import { PageHeader } from "@/components/dashboard/page-header";
import { Button } from "@/components/ui/button";

export default async function ProjectsPage() {
  const projects = await prisma.project.findMany({
    orderBy: {
      createdAt: "desc",
    },
  });

  return (
    <div className="space-y-8">
      <PageHeader
        title="Projects"
        description="Organize every campaign, idea, and creation in one place."
        action={
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New project
          </Button>
        }
      />

      {projects.length === 0 ? (
        <div className="border rounded-xl p-16 text-center">
          <FolderKanban className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />

          <h2 className="text-xl font-semibold">
            Your projects will live here
          </h2>

          <p className="mt-2 text-muted-foreground">
            Create a project to group related AI creations.
          </p>

          <Button asChild className="mt-6">
            <Link href="/studio">
              <Plus className="mr-2 h-4 w-4" />
              Create your first project
            </Link>
          </Button>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <div
              key={project.id}
              className="rounded-xl border p-6 hover:shadow-lg transition"
            >
              <div
                className="mb-4 h-3 w-3 rounded-full"
                style={{
                  backgroundColor: project.color ?? "#7C3AED",
                }}
              />

              <h3 className="text-lg font-semibold">
                {project.name}
              </h3>

              <p className="mt-2 text-sm text-muted-foreground">
                {project.description || "No description"}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}